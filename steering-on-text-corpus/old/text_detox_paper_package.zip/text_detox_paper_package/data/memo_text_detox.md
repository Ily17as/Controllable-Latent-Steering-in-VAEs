# Text Detox Steering Memo
## Goal
Test whether toxicity in text can be controlled by global or local linear steering directions while preserving meaning.
## Dataset setup
- Civil Comments train rows used for direction learning: 9942
- Civil Comments toxic eval rows: 300
- ParaDetox eval enabled: True
## Models
- Sentence encoder: all-mpnet-base-v2
- Toxicity scorer: unitary/toxic-bert
- Rewriter: google/flan-t5-base
## Steering
- Direction key: probe
- Number of local clusters: 8
- Fixed alpha baseline: 1.0
- Probe train AUC on Civil Comments embeddings: 0.8931
## Local clusters
- Mean fallback-to-global rate across clusters: 0.000
- Smallest cluster size: 881
- Largest cluster size: 1702
## Main results
- civil_comments_eval | global | auto: tox drop=0.0927, sem sim=0.9563, accept rate=0.0367, mean alpha=0.0000
- civil_comments_eval | global | fixed: tox drop=0.1923, sem sim=0.8912, accept rate=0.0367, mean alpha=1.0000
- civil_comments_eval | local | auto: tox drop=0.1093, sem sim=0.9498, accept rate=0.0333, mean alpha=0.0017
- civil_comments_eval | local | fixed: tox drop=0.1836, sem sim=0.9004, accept rate=0.0333, mean alpha=1.0000
- paradetox_eval | global | auto: tox drop=0.2775, sem sim=0.8731, accept rate=0.0133, mean alpha=0.0000
- paradetox_eval | global | fixed: tox drop=0.5139, sem sim=0.7244, accept rate=0.0133, mean alpha=1.0000
- paradetox_eval | local | auto: tox drop=0.3332, sem sim=0.8512, accept rate=0.0267, mean alpha=0.0133
- paradetox_eval | local | fixed: tox drop=0.5850, sem sim=0.6960, accept rate=0.0267, mean alpha=1.0000
