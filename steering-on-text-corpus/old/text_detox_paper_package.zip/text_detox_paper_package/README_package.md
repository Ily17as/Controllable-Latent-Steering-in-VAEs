This package contains a standalone paper for the text detox steering experiment.

Files:
- text_detox_steering_paper.tex : LaTeX source
- text_detox_steering_paper.pdf : compiled PDF
- figures/ : figures used in the paper
- data/ : archived CSV files used for the reported numbers

The paper is based on archived run:
20260405_205719_week12_text_detox_steering
