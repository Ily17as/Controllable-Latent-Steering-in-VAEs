# Weekly memo — dSprites OOD extension

## What was done
- Trained a compact dSprites VAE on ID orientations only.
- Trained latent heads for shape and scale.
- Built a local kNN latent direction bank for increasing scale.
- Evaluated fixed-alpha and auto-alpha local steering on ID and OOD splits.

## Dataset split
| split    |   n_samples |   n_groups_approx |
|:---------|------------:|------------------:|
| train    |       21000 |              3500 |
| val      |        3600 |               600 |
| id_test  |        4800 |               800 |
| ood_test |        4800 |               800 |

## Probe quality
| split    | target   |      acc |    n |
|:---------|:---------|---------:|-----:|
| id_test  | shape    | 0.843125 | 4800 |
| ood_test | shape    | 0.801458 | 4800 |
| id_test  | scale    | 0.561042 | 4800 |
| ood_test | scale    | 0.547917 | 4800 |

## Main observations
- Shape probe accuracy: ID = 0.8431, OOD = 0.8015.
- Scale probe accuracy: ID = 0.5610, OOD = 0.5479.
- Best fixed alpha on ID: alpha = 2.00, scale gain = 1.8337, shape consistency = 0.7325, drift = 11.0788.
- Same fixed alpha on OOD: scale gain = 1.8339, shape consistency = 0.7569, drift = 11.1437.
- Best auto setting on ID: tau_img = 7.00, scale gain = 0.6609, shape consistency = 1.0000, alpha_nonzero_rate = 0.7113.
- Same auto setting on OOD: scale gain = 0.6353, shape consistency = 1.0000, alpha_nonzero_rate = 0.6904.

## Interpretation
- If OOD shape consistency stays close to ID while scale gain remains positive, the local steering rule transfers beyond the training support.
- If OOD gain collapses or shape consistency drops, failure is likely tied to representation shift across held-out orientations.

## Risks
- The result may depend strongly on VAE quality and latent disentanglement.
- OOD here is small: only orientation support shifts, not a new dataset.
- Fixed-alpha may over-edit on OOD even if it looks fine on ID.

## Next step
- Compare the same steering recipe against a stronger local direction or nearest-neighbor-conditioned direction on dSprites.