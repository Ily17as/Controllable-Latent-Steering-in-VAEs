# Weekly memo — dSprites OOD extension

## What was done
- Trained a compact dSprites VAE on ID orientations only.
- Trained latent heads for shape and scale.
- Built one global latent direction for increasing scale.
- Evaluated fixed-alpha and auto-alpha steering on ID and OOD splits.

## Dataset split
| split    |   n_samples |   n_groups_approx |
|:---------|------------:|------------------:|
| train    |       21000 |              3500 |
| val      |        3600 |               600 |
| id_test  |        4800 |               800 |
| ood_test |        4800 |               800 |

## Probe quality
| split    | target   |      acc |    n |
|:---------|:---------|---------:|-----:|
| id_test  | shape    | 0.872292 | 4800 |
| ood_test | shape    | 0.843333 | 4800 |
| id_test  | scale    | 0.583125 | 4800 |
| ood_test | scale    | 0.593333 | 4800 |

## Main observations
- Shape probe accuracy: ID = 0.8723, OOD = 0.8433.
- Scale probe accuracy: ID = 0.5831, OOD = 0.5933.
- Best fixed alpha on ID: alpha = 2.00, scale gain = 1.9725, shape consistency = 0.7238, drift = 8.8208.
- Same fixed alpha on OOD: scale gain = 1.9729, shape consistency = 0.7433, drift = 8.8135.
- Best auto setting on ID: tau_img = 7.00, scale gain = 1.0387, shape consistency = 1.0000, alpha_nonzero_rate = 0.8192.
- Same auto setting on OOD: scale gain = 1.0244, shape consistency = 1.0000, alpha_nonzero_rate = 0.8194.

## Interpretation
- If OOD shape consistency stays close to ID while scale gain remains positive, the steering direction transfers beyond the training support.
- If OOD gain collapses or shape consistency drops, failure is likely tied to representation shift across held-out orientations.

## Risks
- The result may depend strongly on VAE quality and latent disentanglement.
- OOD here is small: only orientation support shifts, not a new dataset.
- Fixed-alpha may over-edit on OOD even if it looks fine on ID.

## Next step
- Compare the same steering recipe against a stronger local direction or nearest-neighbor-conditioned direction on dSprites.