# Ready week11 runs package

This archive contains a ready-to-use `week11/runs/...` tree for the stage-11 aggregation notebook/scripts.

## Important note
The original run folders do not encode a single explicit seed in their folder names.
I mapped runs to seed aliases in chronological order under the assumption that you launched them in this order:

`7 -> 11 -> 17 -> 23 -> 31`

If that is true, the mapping is valid. If you launched them in a different order, rename the `seed_XXX` folders accordingly before aggregation.

## Included families
- `dsprites_global`
- `dsprites_local`

Each seed folder includes:
- `config_used.json`
- `memo.md`
- `tables/selected_comparison.csv`
- `tables/fixed_alpha_sweep.csv`
- `tables/auto_alpha_summary.csv`
- `tables/probe_eval.csv`

## Next step
Run:

```bash
python week11/aggregate_seed_tables.py \
  --runs-root week11/runs \
  --output-dir week11/outputs
```

If you already have the stage-11 notebook/scripts, place this `week11/runs` folder next to them.
